package ru.mirea.lab4;

public interface Priceable {
    double getPrice();
}
