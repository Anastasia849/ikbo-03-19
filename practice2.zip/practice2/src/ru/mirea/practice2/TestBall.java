package ru.mirea.practice2;

public class TestBall {
    public static void main(String[] args) {
        Ball b1 =new Ball(1,1);
        b1.move(0.5,0.3);
        System.out.println(b1);
    }
}
