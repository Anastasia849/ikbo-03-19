/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ru.mirea.lab1;

/**
 *
 * @author student
 */
public class var3 {
    
    public static void main(String[] args) {
        float sum =0;
        for(int i =1; i<11;i++){
            sum+=1./i;
        }
        System.out.println(sum);
    }
}
