package ru.mirea.lab6;



import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Game extends JFrame {

    JTextField jtf=new JTextField(10);
    JButton but=new JButton("Ответить");
    JPanel[] pnl = new JPanel[3];

    public Game() {
        super("MyApp");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(500,400);
        setLayout(new FlowLayout());
        add(new JLabel("Угадайте число между 0-20. У вас есть 3 попытки."));
        add(jtf);
        add(but);

        int hiddenNumber= (int) (Math.random() * 20);
        final int[] k = {0};

        but.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                try {
                    int x=Integer.parseInt(jtf.getText().trim());
                    if(x==hiddenNumber){
                        JOptionPane.showMessageDialog(null, "Вы угадали. Это число "+hiddenNumber+".");
                        dispose();
                    }
                    else{
                        k[0]++;
                        if(k[0]==3){
                            JOptionPane.showMessageDialog(null,  "Ваши попытки закончились. Это число " +hiddenNumber+".");
                            dispose();
                        }
                        else {
                            if(x>hiddenNumber)
                                JOptionPane.showMessageDialog(null, "Вы не угадали. Загаданное число меньше введённого.");
                            else
                                JOptionPane.showMessageDialog(null, "Вы не угадали. Загаданное число больше введённого.");
                        }
                    }
                }
                catch (Exception e1){
                    System.out.println(e1.getMessage());
                }
            }
        });


        setVisible(true);
    }


    public static void main(String[] args) {
        new Game();
    }
}
