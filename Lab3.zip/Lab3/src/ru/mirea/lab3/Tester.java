package ru.mirea.lab3;

public class Tester {

    public static void main(String[] args) {
	    Dachshund d1=new Dachshund("Bill",3,5.0);
        System.out.println(d1);
    }
}
